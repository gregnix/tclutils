| package | version | description | category | test | doc | man | repo | path | deps |
|---|---|---|---|---|---|---|---|---|---|
| `tclutils::common` | 0.1 | shared helpers for tclutils modules | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/common-0.1.tm` |  |
| `tclutils::tuagrep` | 0.1 | approximate grep-like routines in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuagrep-0.1.tm` | tclutils::tufuzzy |
| `tclutils::tuappinfo` | 0.1 | collect Tcl/Tk, executable, platform and environment info into a plain text report | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/tuappinfo-0.1.tm` |  |
| `tclutils::tuarchitecture` | 0.1 | parse a Mermaid `architecture-beta` diagram into a tclutils::tudiagram model (SVG or PNG) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuarchitecture-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tuawk` | 0.1 | awk-style record/field processing | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuawk-0.1.tm` |  |
| `tclutils::tubase32` | 0.1 | RFC 4648 base32 (and base32hex) encode/decode. | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tubase32-0.1.tm` | tclutils::common |
| `tclutils::tubase64` | 0.1 | base64 helpers using Tcl core binary encode/decode | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tubase64-0.1.tm` | tclutils::common |
| `tclutils::tubin` | 0.3 | binary helper primitives in pure Tcl | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tubin-0.3.tm` |  |
| `tclutils::tublock` | 0.1 | parse a Mermaid `block-beta` diagram into a tclutils::tudiagram model (SVG or PNG) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tublock-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tubookmark` | 0.1 | read and write the Netscape bookmark file format used by browsers for import/export | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tubookmark-0.1.tm` | tclutils::common,tclutils::tuxml |
| `tclutils::tuc4` | 0.1 | parse a Mermaid C4 diagram into a tclutils::tudiagram model. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuc4-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tucal` | 0.1 | cal-like calendar output in pure Tcl | Date · time/calendar | Y | Y | Y | tclutils | `lib/tm/tclutils/tucal-0.1.tm` | tclutils::common |
| `tclutils::tucat` | 0.1 | small portable cat-like helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tucat-0.1.tm` | tclutils::common |
| `tclutils::tuclass` | 0.1 | parse Mermaid classDiagram into a tclutils::tudiagram model. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuclass-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tucmp` | 0.1 | portable byte-wise file comparison in pure Tcl | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tucmp-0.1.tm` | tclutils::common |
| `tclutils::tucode` | 0.1 | character code tables (ASCII, Latin-1/ANSI, signs) | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tucode-0.1.tm` | tclutils::common |
| `tclutils::tucodepng` | 0.1 | render a character-code table (ASCII / Latin-1) to a PNG code-page grid | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tucodepng-0.1.tm` | tclutils::common,tclutils::tupngdraw,tclutils::tucode |
| `tclutils::tucolor` | 0.1 | named-color database and conversions. | Terminal · color | Y | Y | Y | tclutils | `lib/tm/tclutils/tucolor-0.1.tm` |  |
| `tclutils::tucolumn` | 0.1 | column-like columnation in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tucolumn-0.1.tm` | tclutils::common |
| `tclutils::tucomm` | 0.1 | comm-like helpers for sorted line sets | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tucomm-0.1.tm` | tclutils::common |
| `tclutils::tucrc` | 0.1 | CRC and Adler checksum helpers using Tcl core zlib | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tucrc-0.1.tm` | tclutils::common |
| `tclutils::tucsplit` | 0.1 | split text files by content patterns | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tucsplit-0.1.tm` | tclutils::common |
| `tclutils::tucsv` | 0.1 | small CSV helpers | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tucsv-0.1.tm` | tclutils::common |
| `tclutils::tucut` | 0.1 | cut-like helpers for simple delimited text and characters | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tucut-0.1.tm` | tclutils::common |
| `tclutils::tudate` | 0.1 | flexible date helpers on top of the Tcl clock command. | Date · time/calendar | Y | Y | Y | tclutils | `lib/tm/tclutils/tudate-0.1.tm` | tclutils::common |
| `tclutils::tudav` | 0.1 | a minimal WebDAV / CardDAV / CalDAV client. | Network · web | Y | Y | Y | tclutils | `lib/tm/tclutils/tudav-0.1.tm` | tclutils::common,tclutils::tubase64,tclutils::tuxml,http,tls |
| `tclutils::tudeploy` | 0.1 | runtime discovery and loading of Tcl module packages from app-relative deployment roots | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/tudeploy-0.1.tm` |  |
| `tclutils::tudiagram` | 0.4 | box-and-arrow diagrams in pure Tcl. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tudiagram-0.4.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tudict` | 0.1 | dict helpers beyond what the Tcl core dict already does. | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tudict-0.1.tm` |  |
| `tclutils::tudiff` | 0.1 | portable line based diff tools in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tudiff-0.1.tm` | tclutils::common |
| `tclutils::tuer` | 0.2 | parse Mermaid erDiagram into a tclutils::tudiagram model. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuer-0.2.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tuevent` | 0.1 | a small publish/subscribe event bus. | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tuevent-0.1.tm` | tclutils::common |
| `tclutils::tuexe` | 0.1 | locate external executables | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/tuexe-0.1.tm` |  |
| `tclutils::tuexpand` | 0.1 | expand/unexpand (tabs <-> spaces) in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuexpand-0.1.tm` | tclutils::common |
| `tclutils::tufetch` | 0.3 | tiny HTTP(S) helper: GET/POST into memory or to a file. | Network · web | Y | Y | Y | tclutils | `lib/tm/tclutils/tufetch-0.3.tm` | tclutils::common,http,tls |
| `tclutils::tufile` | 0.1 | file type detection by magic signatures | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tufile-0.1.tm` |  |
| `tclutils::tufind` | 0.1 | portable file finder in pure Tcl | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tufind-0.1.tm` |  |
| `tclutils::tuflow` | 0.2 | a compact flowchart text syntax for tudiagram. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuflow-0.2.tm` | tclutils::tudiagram,tclutils::tustate,tclutils::turequirement,tclutils::tuer,tclutils::tuclass,tclutils::tumindmap,tclutils::tuc4,tclutils::tublock,tclutils::tugit,tclutils::tuarchitecture,tclutils::tupie,tclutils::tuxychart,tclutils::tuquadrant,tclutils::tujourney,tclutils::tutimeline,tclutils::tusankey,tclutils::tugantt,tclutils::tusequence,tclutils::turadar,tclutils::tutreemap,tclutils::tupacket,tclutils::tukanban |
| `tclutils::tufmt` | 0.1 | reflow text paragraphs to a target width (like fmt(1)). | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tufmt-0.1.tm` | tclutils::common |
| `tclutils::tufold` | 0.1 | fold-like text wrapping helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tufold-0.1.tm` | tclutils::common |
| `tclutils::tufuzzy` | 0.1 | fuzzy matching primitives in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tufuzzy-0.1.tm` |  |
| `tclutils::tugantt` | 0.1 | parse and render a Mermaid `gantt` block to SVG or PNG. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tugantt-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tugit` | 0.1 | parse a Mermaid `gitGraph` into a tclutils::tudiagram model (SVG or PNG) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tugit-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tugrep` | 0.1.2 | portable grep-like routines in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tugrep-0.1.2.tm` |  |
| `tclutils::tuhash` | 0.1 | pure-Tcl cryptographic digests (SHA-256, SHA-1, MD5) | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tuhash-0.1.tm` | tclutils::common |
| `tclutils::tuhead` | 0.1 | head-like helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuhead-0.1.tm` |  |
| `tclutils::tuhexdump` | 0.1 | classic hex/ascii dump in pure Tcl | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tuhexdump-0.1.tm` | tclutils::common,tclutils::tubin |
| `tclutils::tuhexedit` | 0.1 | small binary read/write/search/patch helpers | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tuhexedit-0.1.tm` | tclutils::common,tclutils::tubin,tclutils::tuhexdump |
| `tclutils::tuholiday` | 0.1 | public-holiday dates from the Easter computus. | Date · time/calendar | Y | Y | Y | tclutils | `lib/tm/tclutils/tuholiday-0.1.tm` | tclutils::common |
| `tclutils::tuical` | 0.1 | iCalendar (RFC 5545) reader/writer | Date · time/calendar | Y | Y | Y | tclutils | `lib/tm/tclutils/tuical-0.1.tm` |  |
| `tclutils::tuiconv` | 0.1 | small encoding conversion helpers in pure Tcl | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tuiconv-0.1.tm` | tclutils::common |
| `tclutils::tuimage` | 0.1 | pure-Tcl image inspection: format, MIME type and pixel dimensions, plus data: URI helpers | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tuimage-0.1.tm` | tclutils::tubase64 |
| `tclutils::tuini` | 0.1 | INI file reader/writer | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tuini-0.1.tm` |  |
| `tclutils::tujoin` | 0.1.1 | simple join-like helpers for delimited text | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tujoin-0.1.1.tm` | tclutils::common |
| `tclutils::tujourney` | 0.1 | parse and render a Mermaid `journey` block to SVG or PNG (pure-Tcl backends) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tujourney-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tujson` | 0.1 | small JSON helper in pure Tcl | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tujson-0.1.tm` | tclutils::common |
| `tclutils::tukanban` | 0.1 | a Mermaid-style kanban renderer for the tuflow family. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tukanban-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tulayout` | 0.1 | page layout helpers (mm coordinates, block dicts) | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tulayout-0.1.tm` |  |
| `tclutils::tuldif` | 0.1 | LDIF (RFC 2849) reader/writer | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tuldif-0.1.tm` | tclutils::tubase64 |
| `tclutils::tulist` | 0.1 | functional list helpers that the Tcl core does not provide directly. | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tulist-0.1.tm` |  |
| `tclutils::tulog` | 0.1 | a small, dependency-free leveled logger. Pure Tcl, 8.6+/9.x. | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/tulog-0.1.tm` | tclutils::common |
| `tclutils::tumath` | 0.1 | small numeric helpers the core expr does not provide directly. | Numeric · validation | Y | Y | Y | tclutils | `lib/tm/tclutils/tumath-0.1.tm` |  |
| `tclutils::tumd` | 0.1 | minimal Markdown helpers (CommonMark subset) | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tumd-0.1.tm` |  |
| `tclutils::tumindmap` | 0.1 | parse a Mermaid mindmap into a tclutils::tudiagram model. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tumindmap-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tummdb` | 0.1 | a pure-Tcl reader for the MaxMind DB (.mmdb) binary format, version 2.0 of the spec. | Network · web | Y | Y | Y | tclutils | `lib/tm/tclutils/tummdb-0.1.tm` | tclutils::tubin |
| `tclutils::tumonthpng` | 0.4 | render a month calendar to a PNG image, mirroring the monthcanvas Tk widget | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tumonthpng-0.4.tm` | tclutils::common,tclutils::tupngdraw |
| `tclutils::tunl` | 0.1 | nl-like line numbering in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tunl-0.1.tm` | tclutils::common |
| `tclutils::tunotes` | 0.1 | hierarchical note store | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tunotes-0.1.tm` | tclutils::common,tclutils::tujson |
| `tclutils::tunum` | 0.3 | robust parsing of human-formatted numbers and summation. | Numeric · validation | Y | Y | Y | tclutils | `lib/tm/tclutils/tunum-0.3.tm` |  |
| `tclutils::tunumany` | 0.1 | a single entry point for string-to-number that routes to the right backend | Numeric · validation | Y | Y | Y | tclutils | `lib/tm/tclutils/tunumany-0.1.tm` | tclutils::tunumfmt,tclutils::tunum |
| `tclutils::tunumfmt` | 0.1 | numfmt-like human-readable number formatting in pure Tcl | Numeric · validation | Y | Y | Y | tclutils | `lib/tm/tclutils/tunumfmt-0.1.tm` | tclutils::common |
| `tclutils::tuod` | 0.1 | small od-like binary dump helpers in pure Tcl | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tuod-0.1.tm` | tclutils::common,tclutils::tubin |
| `tclutils::tuodf` | 0.1 | minimal OpenDocument (ODF) text helpers | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tuodf-0.1.tm` | tclutils::common,tclutils::tuzip |
| `tclutils::tuopen` | 0.1 | open a URL or file path with the operating system's default application (xdg-open / open / cmd start). | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/tuopen-0.1.tm` | tclutils::common |
| `tclutils::tupacket` | 0.1 | parse and render a Mermaid `packet-beta` block to SVG or PNG (pure-Tcl backends) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tupacket-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tupagespec` | 0.1 | parse and format page-range specifications | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tupagespec-0.1.tm` |  |
| `tclutils::tupaste` | 0.1 | paste-like helpers for combining line streams | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tupaste-0.1.tm` | tclutils::common |
| `tclutils::tupatch` | 0.1 | patch-like applier for unified diffs | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tupatch-0.1.tm` | tclutils::common |
| `tclutils::tupath` | 0.1 | path utilities (normalize, lexical clean, commonpath, ...) | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tupath-0.1.tm` | tclutils::common |
| `tclutils::tupdf` | 0.1 | minimal PDF structure inspector (read-only) | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tupdf-0.1.tm` | tclutils::common |
| `tclutils::tupie` | 0.1 | a Mermaid-style pie chart renderer for the tuflow family. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tupie-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tupkgfinder` | 0.1 | inspect how Tcl resolves packages: versions, ifneeded scripts, locations, active vs shadowed | System · runtime | Y | Y | Y | tclutils | `lib/tm/tclutils/tupkgfinder-0.1.tm` |  |
| `tclutils::tupng` | 0.4 | a pure-Tcl PNG encoder (no Tk, no external packages; uses only the core "zlib" command). | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tupng-0.4.tm` | tclutils::common |
| `tclutils::tupngdraw` | 0.12 | a tiny pure-Tcl 2D drawing layer that renders to a PNG via tclutils::tupng. | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tupngdraw-0.12.tm` | tclutils::common,tclutils::tupng,TclOO |
| `tclutils::tupngpad` | 0.1 | normalise a set of (transparent) PNGs to a uniform size. | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tupngpad-0.1.tm` | tclutils::common,tclutils::tupng,tclutils::tupngdraw |
| `tclutils::tupr` | 0.1 | pr-like simple page formatting in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tupr-0.1.tm` | tclutils::common |
| `tclutils::tuquadrant` | 0.1 | parse and render a Mermaid `quadrantChart` block to SVG or PNG (pure-Tcl backends) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuquadrant-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::turadar` | 0.1 | parse a Mermaid `radar-beta` block and render a radar/spider chart to SVG or PNG | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/turadar-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::turegistry` | 0.1 | a small keyed value registry (service locator / bag). | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/turegistry-0.1.tm` | tclutils::common |
| `tclutils::turequirement` | 0.1 | parse Mermaid requirementDiagram into a tclutils::tudiagram model. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/turequirement-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::turev` | 0.1 | rev-like reversal of characters within each line | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/turev-0.1.tm` | tclutils::common |
| `tclutils::turrule` | 0.1 | expand iCalendar RRULE recurrence rules into occurrences. | Date · time/calendar | Y | Y | Y | tclutils | `lib/tm/tclutils/turrule-0.1.tm` | tclutils::common,tclutils::tuical |
| `tclutils::tusankey` | 0.1 | parse and render a Mermaid `sankey-beta` block to SVG or PNG. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tusankey-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tused` | 0.1.3 | small sed-like text replacement/filter routines in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tused-0.1.3.tm` | tclutils::common |
| `tclutils::tuseq` | 0.1 | seq-like numeric sequence generation in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuseq-0.1.tm` | tclutils::common |
| `tclutils::tusequence` | 0.1 | parse and render a Mermaid `sequenceDiagram` block to SVG or PNG. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tusequence-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tushuf` | 0.1 | shuf-like line shuffling in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tushuf-0.1.tm` | tclutils::common |
| `tclutils::tusize` | 0.1 | directory/file sizes (a small `du`) | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tusize-0.1.tm` | tclutils::common |
| `tclutils::tusort` | 0.1 | sort-like helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tusort-0.1.tm` | tclutils::common |
| `tclutils::tusparql` | 0.1 | a thin SPARQL client. | Network · web | Y | Y | Y | tclutils | `lib/tm/tclutils/tusparql-0.1.tm` | tclutils::common,tclutils::tufetch,tclutils::tujson,tclutils::tuurl |
| `tclutils::tusplit` | 0.1 | split files into smaller parts | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tusplit-0.1.tm` | tclutils::common |
| `tclutils::tusqlite` | 0.1 | thin, safe helpers over an existing sqlite3 db command. | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tusqlite-0.1.tm` | tclutils::common |
| `tclutils::tustat` | 0.1 | stat-like file metadata helpers | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tustat-0.1.tm` | tclutils::common |
| `tclutils::tustate` | 0.1 | parse Mermaid stateDiagram / stateDiagram-v2 into a tclutils::tudiagram model. | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tustate-0.1.tm` | tclutils::common,tclutils::tudiagram |
| `tclutils::tustr` | 0.1 | small string helpers the Tcl core lacks (case, padding/centering, affixes, slug) | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tustr-0.1.tm` |  |
| `tclutils::tustrings` | 0.1 | extract printable strings from binary data | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tustrings-0.1.tm` | tclutils::common |
| `tclutils::tusvg` | 0.2 | SVG canvas, congruent with the tupngdraw object API. | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tusvg-0.2.tm` | TclOO,tclutils::common |
| `tclutils::tutable` | 0.1 | render a text table from headers + rows. | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tutable-0.1.tm` | tclutils::common |
| `tclutils::tutablepng` | 0.1 | render tabular data to a PNG table image via tclutils::tupngdraw (no Tk) | Graphics · raster/vector | Y | Y | Y | tclutils | `lib/tm/tclutils/tutablepng-0.1.tm` | tclutils::common,tclutils::tupngdraw |
| `tclutils::tutac` | 0.1 | tac-like reversal of line order | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tutac-0.1.tm` | tclutils::common |
| `tclutils::tutail` | 0.1 | tail-like helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tutail-0.1.tm` |  |
| `tclutils::tutee` | 0.1 | tee-like helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tutee-0.1.tm` | tclutils::common |
| `tclutils::tuterm` | 0.1 | ANSI terminal styling (SGR): attributes and 16/256/24-bit colors (honours NO_COLOR) | Terminal · color | Y | Y | Y | tclutils | `lib/tm/tclutils/tuterm-0.1.tm` | twapi |
| `tclutils::tutimeline` | 0.1 | parse and render a Mermaid `timeline` block to SVG or PNG (pure-Tcl backends) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tutimeline-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tutr` | 0.1 | tr-like character translate/delete helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tutr-0.1.tm` | tclutils::common |
| `tclutils::tutreemap` | 0.1 | parse a Mermaid `treemap-beta` block and render a squarified treemap to SVG or PNG | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tutreemap-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tutsort` | 0.1 | tsort-like topological sort in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tutsort-0.1.tm` | tclutils::common |
| `tclutils::tuuniq` | 0.1 | uniq-like helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuuniq-0.1.tm` | tclutils::common |
| `tclutils::tuurl` | 0.1 | URL percent-encoding/decoding and query strings (UTF-8). | Network · web | Y | Y | Y | tclutils | `lib/tm/tclutils/tuurl-0.1.tm` | tclutils::common |
| `tclutils::tuuuid` | 0.1 | UUID generation and inspection (pure Tcl). | Encoding · binary/checksums | Y | Y | Y | tclutils | `lib/tm/tclutils/tuuuid-0.1.tm` | tclutils::common |
| `tclutils::tuvalidate` | 0.1 | small format/type validation predicates. | Numeric · validation | Y | Y | Y | tclutils | `lib/tm/tclutils/tuvalidate-0.1.tm` |  |
| `tclutils::tuvcard` | 0.1 | vCard (RFC 6350 / 2426) reader/writer | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tuvcard-0.1.tm` | tclutils::tubase64,tclutils::tuimage |
| `tclutils::tuwc` | 0.1 | portable word/line/char/byte counter in pure Tcl | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuwc-0.1.tm` | tclutils::common |
| `tclutils::tuxargs` | 0.1 | xargs-like list batching helpers | Text · strings/coreutils | Y | Y | Y | tclutils | `lib/tm/tclutils/tuxargs-0.1.tm` | tclutils::common |
| `tclutils::tuxml` | 0.1 | small XML text helper in pure Tcl | Data · structures & formats | Y | Y | Y | tclutils | `lib/tm/tclutils/tuxml-0.1.tm` | tclutils::common |
| `tclutils::tuxychart` | 0.1 | parse and render a Mermaid `xychart-beta` block to SVG or PNG (pure-Tcl backends) | Diagrams · Mermaid | Y | Y | Y | tclutils | `lib/tm/tclutils/tuxychart-0.1.tm` | tclutils::common,Glyphs,tclutils::tusvg,tclutils::tupngdraw |
| `tclutils::tuzip` | 0.1 | small ZIP/ODF helper in pure Tcl | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tuzip-0.1.tm` | zlib,tclutils::common,tclutils::tubin |
| `tclutils::tuzipfs` | 0.1 | small Tcl 9 zipfs convenience wrapper | Archive · filesystem | Y | Y | Y | tclutils | `lib/tm/tclutils/tuzipfs-0.1.tm` | tclutils::common |
